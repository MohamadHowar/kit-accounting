## Module <base_accounting_kit>

#### 07.10.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Odoo 18 Full Accounting Kit for Community

#### 22.10.2024
#### Version 18.0.1.0.1
#### UPDT
- Added the reconciliation widget and lock dates.

